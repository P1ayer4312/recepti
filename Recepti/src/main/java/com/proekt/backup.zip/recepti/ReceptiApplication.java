package com.proekt.recepti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceptiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReceptiApplication.class, args);
    }

}
