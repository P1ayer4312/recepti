package com.proekt.recepti.service;

import com.proekt.recepti.model.LoginModel;
import com.proekt.recepti.repository.RegisterRepository;
import org.springframework.stereotype.Service;

@Service
public class RegisterService {

    private RegisterRepository registerRepository;
    public RegisterService(RegisterRepository registerRepository) {
        this.registerRepository = registerRepository;
    }

    public LoginModel saveUser(LoginModel user) {
        return this.registerRepository.save(user);
    }
}
