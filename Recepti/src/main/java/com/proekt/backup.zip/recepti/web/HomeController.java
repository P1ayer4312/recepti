package com.proekt.recepti.web;

import com.proekt.recepti.model.LoginModel;
import com.proekt.recepti.service.RegisterService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

//@Controller
//@RequestMapping("/")
public class HomeController {

//    private RegisterService registerService;
//
//    public HomeController(RegisterService registerService) {
//        this.registerService = registerService;
//    }
//
//
//    @GetMapping
//    public String homePage(Model model) {
//        model.addAttribute("loggedIn", false);
//        model.addAttribute("test", "hello from controller");
//        return "index";
//    }
//
//    @GetMapping("/login")
//    public String loginPage() {
//        return "login";
//    }
//
//    @PostMapping("/login")
//    public String login(@RequestParam String username,
//                        @RequestParam String password,
//                        Model model
//    ) {
//        return "login";
//    }
//
//
//    @GetMapping("/register")
//    public String registerPage() {
//        return "register";
//    }
//
//    @PostMapping("/register")
//    public String register(@RequestParam String username,
//                           @RequestParam String password,
//                           @RequestParam String email,
//                           Model model
//    ) {
//        System.out.printf("%s %s %s", username, password, email);
//        LoginModel newUser = new LoginModel(username, password, email);
//        this.registerService.saveUser(newUser);
//        model.addAttribute("loggedIn", true);
//        return "index";
//    }





}
