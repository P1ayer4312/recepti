package com.proekt.recepti.model;

import com.sun.istack.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@NoArgsConstructor
public class LoginModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false, unique = true)
    private String email;

    @NotNull
    public String role;

    private LocalDateTime registrationDate;

    public LoginModel(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.registrationDate = LocalDateTime.now();
        this.role = "USER";
    }
}
